import { Pool } from "pg";
import dotenv from "dotenv";

dotenv.config();

export const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: Number(process.env.DB_PORT),
});

/**
 * Verify the pool can connect on startup.
 * Logs status; never throws (so the server still boots and
 * serves /api/health for diagnostics).
 */
export const ensureDbConnected = async (): Promise<void> => {
  try {
    const client = await pool.connect();
    client.release();
    console.log("✅ PostgreSQL Connected");
  } catch (err) {
    console.error("❌ Database connection error:", err);
  }
};
