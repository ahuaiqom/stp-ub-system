# STP-UB System

Dashboard agregasi data **Kawasan Sains & Teknologi (KST) Jatikerto** — Universitas Brawijaya.
Monolit fullstack: backend Express+TypeScript, frontend React+Vite, database PostgreSQL.

API backend mengikuti **Kontrak KST Dashboard v0.0.1** (`kst-integration/contract/`).

---

## Fitur

- **Halaman publik** — tampilkan komoditas pertanian, peternakan, akademik, konservasi, kemitraan secara read-only.
- **Halaman admin** dengan login JWT + auto-refresh, RBAC `admin` / `viewer`.
- **CRUD penuh** untuk 6 modul data (Pertanian, Peternakan, Konservasi Hewan, Konservasi Tanaman, Pelayanan Akademik, Kemitraan) sesuai kontrak `table` (POST insert, PATCH partial update, PATCH null = delete).
- **Manajemen user** (admin only): list, tambah, edit, hapus.
- **Aggregate query** `/query` dengan kode UUIDv6 per data.
- **Health check** `/health`.
- **Rate limiting** in-memory + standar HTTP 429 + header `Retry-After`.

---

## Stack

| Layer    | Tools                                                              |
| -------- | ------------------------------------------------------------------ |
| Frontend | React 19, Vite 8, TypeScript, React Router 7, Tailwind 4, plain CSS |
| Backend  | Node.js 20+, Express 5, TypeScript, jsonwebtoken, bcryptjs, pg      |
| DB       | PostgreSQL 15+                                                      |

---

## Quick Start (Linux / macOS)

Pastikan PostgreSQL sudah jalan dan database `stp_ub_db` sudah dibuat.

```bash
git clone <REPO_URL> stp-ub-system
cd stp-ub-system

# 1. Backend
cd backend
cp .env.example .env          # atau buat .env manual (lihat docs/WINDOWS_SETUP.md §4.2)
npm install
npm run db:bootstrap           # init schema + migrate + seed + buat admin default

# 2. Frontend (terminal baru)
cd ../frontend
npm install

# 3. Run keduanya (2 terminal)
cd ../backend && npm run dev   # http://localhost:5000
cd ../frontend && npm run dev  # http://localhost:5173
```

Buka http://localhost:5173/admin/login dan login dengan:

```
username: admin
password: admin123
```

---

## Quick Start (Windows)

Lihat panduan lengkap di **[docs/WINDOWS_SETUP.md](docs/WINDOWS_SETUP.md)**.

Ringkas:
```powershell
cd stp-ub-system\backend
npm install
# buat backend\.env (lihat dokumen)
npm run db:bootstrap
npm run dev

# di terminal lain
cd stp-ub-system\frontend
npm install
npm run dev
```

---

## Dokumentasi

| Dokumen                                              | Isi                                                          |
| ---------------------------------------------------- | ------------------------------------------------------------ |
| [docs/API.md](docs/API.md)                           | Referensi endpoint lengkap (auth, contract, data CRUD, query, public, error codes) |
| [docs/WINDOWS_SETUP.md](docs/WINDOWS_SETUP.md)       | Setup detail di Windows + troubleshooting                    |
| [kst-integration/contract/](kst-integration/contract/) | Kontrak KST Dashboard v0.0.1                                 |

---

## Struktur Projek

```
stp-ub-system/
├── backend/
│   ├── src/
│   │   ├── config/             # db pool
│   │   ├── contracts/          # DataDesc per modul (sesuai kontrak)
│   │   ├── middlewares/        # auth, rbac, error, rate limit
│   │   ├── routes/             # auth, contract, data, query, users, public, health
│   │   ├── services/           # CRUD per modul + dispatcher
│   │   ├── types/              # api, contract, table, jwt
│   │   ├── utils/              # response, jwt, pagination, uuid
│   │   ├── validators/
│   │   └── index.ts            # entry point
│   ├── scripts/
│   │   ├── bootstrap.ts        # one-shot setup
│   │   ├── migrate.ts
│   │   ├── seed.ts             # juga set bcrypt admin
│   │   └── test-all.sh         # smoke test e2e (53 assertions)
│   ├── package.json
│   └── tsconfig.json
│
├── frontend/
│   ├── src/
│   │   ├── admin-site/
│   │   │   ├── components/     # DataTable, Modal, RowFormModal, etc.
│   │   │   ├── context/        # AuthContext (JWT, auto-refresh)
│   │   │   ├── hooks/          # useAdminTable
│   │   │   ├── layouts/        # AdminLayout (sidebar + topbar)
│   │   │   └── pages/          # 5 halaman admin (Pertanian, dst) + LoginPage
│   │   ├── public-site/
│   │   │   ├── components/     # Hero, Activity, Activity2, PublicTable,
│   │   │   │                   # Peternakan, Konservasi, Akademik,
│   │   │   │                   # Partnership, Footer
│   │   │   └── pages/HomePage.tsx
│   │   ├── services/           # api.ts, auth.api.ts, admin.api.ts, public.api.ts
│   │   ├── routes/AppRoutes.tsx
│   │   └── App.tsx
│   ├── vite.config.ts
│   └── package.json
│
├── database/
│   ├── 000_schema_init.sql     # schema + sample data (idempotent)
│   ├── migrations/
│   │   └── 001_kst_compat.sql  # row_uuid, role, timestamps, konservasi_tanaman
│   ├── seeds/
│   │   └── 001_dummy.sql       # konservasi/akademik/kemitraan extras
│   └── stp_ub_db_dump.sql      # dump asli (referensi)
│
├── kst-integration/contract/   # kontrak API KST (v0.0.1)
└── docs/
    ├── API.md
    └── WINDOWS_SETUP.md
```

---

## Verifikasi Sistem

Smoke test end-to-end ada di `backend/scripts/test-all.sh`. Jalankan setelah backend up:

```bash
# Linux / macOS / Git Bash / WSL
bash backend/scripts/test-all.sh
```

Hasilnya:
```
== Summary ==
  Passed: 53 / 53
  Failed: 0 / 53

All tests passed.
```

Yang dicek:
- Auth: login (sukses + 400 + 401), refresh, logout
- Contract: 6 modul terdaftar
- 6 modul × {GET, POST, PATCH update, PATCH delete}
- Aggregate `/query` (sukses + per-item error)
- Users CRUD + 409 duplicate
- RBAC: viewer dilarang write & list users
- 5 endpoint public
- 404 untuk path tidak dikenal

---

## URL Penting (Development)

| URL                                       | Fungsi                                |
| ----------------------------------------- | ------------------------------------- |
| http://localhost:5173/                    | Halaman publik                        |
| http://localhost:5173/admin/login         | Login admin                           |
| http://localhost:5173/admin/pertanian     | Dashboard Pertanian                   |
| http://localhost:5173/admin/peternakan    | Dashboard Peternakan                  |
| http://localhost:5173/admin/konservasi    | Dashboard Konservasi (Hewan/Tanaman)  |
| http://localhost:5173/admin/akademik      | Dashboard Pelayanan Akademik          |
| http://localhost:5173/admin/kemitraan     | Dashboard Kemitraan                   |
| http://localhost:5000/api/health          | Health check                          |
| http://localhost:5000/api/contract        | Kontrak data (perlu Bearer token)     |

---

## Lisensi

Internal — Universitas Brawijaya / KST Jatikerto.
